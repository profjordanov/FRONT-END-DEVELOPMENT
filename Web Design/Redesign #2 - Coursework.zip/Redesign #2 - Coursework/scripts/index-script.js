jQuery(document).ready(function(){
    jQuery( "#tabs" ).tabs();
    jQuery( ".fancybox" ).fancybox();
});
